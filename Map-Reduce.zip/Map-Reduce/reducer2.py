#!/usr/bin/env python
import sys
current_key = None
counts=dict()
#total = 0
for line in sys.stdin:
    key, val = line.strip().split("\t")
    if current_key == key:
        result.append(val)
    else:
        if current_key is not None:
            for r in result:
                if r not in counts:
                    counts[r]=1
                else:
                    counts[r]=counts[r]+1
            sys.stdout.write("{0}\t{1}\n".format(current_key, counts))
        current_key = key
        result = [val]
if current_key is not None:
    sys.stdout.write("{0}\t{1}\n".format(current_key, result))

