#!/usr/bin/env python
import sys
import os
import re
for line in sys.stdin:
    line = line.strip().lower()
    line = re.sub(r'[^a-z_\s]+', '',line)
    filename = os.getenv('map_input_file')
    if filename :
        filename=filename.split("/")[-1]
    for word in line.split():
        if len(word) > 6:
	    if word[0] in ['a','e','i','o','u']:
                sys.stdout.write("{0}\t{1}\n".format(word,filename))
