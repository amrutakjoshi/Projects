#!/usr/bin/env python
import sys
current_key = None
#total = 0
for line in sys.stdin:
    key, val = line.strip().split("\t")
    if current_key == key:
        result.append(val)
    else:
        if current_key is not None:
        	sys.stdout.write("{0}\t{1}\n".format(current_key, list(set(result))))
        current_key = key
        result = [val]
if current_key is not None:
    sys.stdout.write("{0}\t{1}\n".format(current_key, list(set(result))))
